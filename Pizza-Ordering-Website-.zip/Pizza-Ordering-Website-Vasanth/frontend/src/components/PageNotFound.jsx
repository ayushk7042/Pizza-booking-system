import React from 'react'

const PageNotFound = () => {
  return (
    <div className='pageNotFound'>
        <h1>Page Not Found, 404 Error </h1>
    </div>
  )
}

export default PageNotFound